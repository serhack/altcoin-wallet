<?php if (!defined("IN_WALLET")) { die("u can't touch this."); } ?>
