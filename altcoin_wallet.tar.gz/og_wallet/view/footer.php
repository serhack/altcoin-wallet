<?php if (!defined("IN_WALLET")) { die("u can't touch this."); } ?>
<?php //PLEASE DO NOT REMOVE OR CHANGE THE POWERED BY LINK. THIS IS THE ONLY RECOGNITION I ASK FOR ?>
            </div>
        </div>



</center></b>
<style>
$(".sexytabs").tabs({
  show: { effect: "slide", direction: "left", duration: 200, easing: "easeOutBack" } ,
  hide: { effect: "slide", direction: "right", duration: 200, easing: "easeInQuad" }
});
</style>

    </body>
</html>
